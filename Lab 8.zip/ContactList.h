#pragma once
#include "Contact.h"
const int MAX_CONTACTS = 5;
const int NOT_FOUND = -1;
class contactList
{
private:
	int Numcontacts;
	contact Contacts[MAX_CONTACTS];
	string listName;
public:
	contactList();
	void SetListName(string n);
	string getName ();
	void Addcontact(contact c);
	int SearchByName(string n);
	contact getcontact(int index);
	int getNumContacts();
	void print();
};