#pragma once
# include <string>
#include <iomanip>
using namespace std;
class contact{
private:
	string Name;
	string Phone;
public:
	contact();
	void setName(string n);
	void setPhone(string p);
	string getName();
	string getPhone();
	void print();

	

};