#include "Contact.h"
#include <iostream>
using namespace std;
contact::contact() {
	Name = "Empty";
	Phone = "";
}
void contact::setName(string n) {
	Name = n;
}
void contact::setPhone(string p) {
	Phone = p;
}
string contact::getName() {
	return Name;
}
string contact::getPhone() {
	return Phone;
}
void contact::print() {
	cout << setw(12) << Phone << " " << Name << endl;

}