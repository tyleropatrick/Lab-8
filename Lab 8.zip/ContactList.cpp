#include "ContactList.h"
#include <iostream>
using namespace std;
 contactList::contactList() {
	 listName = "None";
	 Numcontacts = 0;
}
 void contactList::SetListName(string n) {
	 listName = n;
	 
}
 string contactList::getName() {
	 return listName;
}
 int contactList:: getNumContacts() {
	 return Numcontacts;
 }
 void contactList::Addcontact(contact c) {
	 if (Numcontacts < MAX_CONTACTS)
	 {
		 Contacts[Numcontacts] = c;
		 Numcontacts++;
	 }
	 else
		 cout << "contactList::addContact(): max contacts exceeded! " << c.getName() << endl << " not added!" << endl;
}
 int contactList::SearchByName(string n) {
	 for (int i = 0; i < Numcontacts; i++)
	 {
		 if (Contacts[i].getName() == n)
		 {
			 return i;
		 }
		 else
			 return NOT_FOUND;
	 }

}
 contact contactList::getcontact(int index) {
	 if (index <= Numcontacts && index >= 0)
	 {
		 return Contacts[index];
	 }
	 else
	 {
		 contact c;
		 return c; 
	 }

}
 void contactList::print() {
	 cout << "List:" << listName << " (" << Numcontacts << " contacts)" << endl;


}